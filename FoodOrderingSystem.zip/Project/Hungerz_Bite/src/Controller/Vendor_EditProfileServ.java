package Controller;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.mysql.jdbc.PreparedStatement;

import Action_Class.Vendor_EditProfile;
import Model.Vendor;

/**
 * Servlet implementation class Vendor_EditProfileServ
 */
@WebServlet(name = "Vendor_EditProfile", urlPatterns = { "/Vendor_EditProfile" })
public class Vendor_EditProfileServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vendor_EditProfileServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		
		if(s.getAttribute("VENDOR")!=null)
		{
			Vendor v=new Vendor();
			v.setCity(request.getParameter("city"));
			v.setContact(request.getParameter("contact"));
			v.setLocality(request.getParameter("locality"));
			v.setName(request.getParameter("name"));
			v.setPicture(request.getParameter("picture"));
			v.setE_mail((String)s.getAttribute("VENDOR"));
			/*InputStream inputStream = null;	
			Part filePart = request.getPart("picture");

				if (filePart != null) {
				
					inputStream = filePart.getInputStream();
				}
				String sql = "INSERT INTO u (photo) values (?)";
                PreparedStatement stat = con.prepareStatement(sql);
                
                       if (inputStream != null) {
				
				stat.setBlob(1, inputStream);
			}*/
			Vendor_EditProfile ob=new Vendor_EditProfile();
			ob.edit(v);
			
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Home.jsp");
			request.setAttribute("error", "Profile Updated successfully");
			rd.include(request, response);
			
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Login.jsp");
			request.setAttribute("error", "Make sure you are logged in");
			rd.include(request, response);
		}
		
	}

}

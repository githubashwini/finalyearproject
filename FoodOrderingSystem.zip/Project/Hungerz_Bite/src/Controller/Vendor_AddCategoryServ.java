package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Action_Class.Vendor_AddCategory;

/**
 * Servlet implementation class Vendor_AddCategoryServ
 */
@WebServlet(name = "Vendor_AddCategory", urlPatterns = { "/Vendor_AddCategory" })
public class Vendor_AddCategoryServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vendor_AddCategoryServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		if(s.getAttribute("VENDOR")!=null)
		{
			
			String str=(String)s.getAttribute("VENDOR");
			Vendor_AddCategory ob=new Vendor_AddCategory();
			ob.add(str,request.getParameter("name"));
			
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_AddItem.jsp");
			request.setAttribute("error", "Category added successfully");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Login.jsp");
			request.setAttribute("error", "Make sure you are logged in");
			rd.include(request, response);
		}
	}

}

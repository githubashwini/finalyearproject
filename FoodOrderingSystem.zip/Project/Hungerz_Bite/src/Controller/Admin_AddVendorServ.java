package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Action_Class.AddVendor;
import Model.Vendor;

/**
 * Servlet implementation class Admin_AddVendorServ
 */
@WebServlet(name = "Admin_AddVendor", urlPatterns = { "/Admin_AddVendor" })
public class Admin_AddVendorServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admin_AddVendorServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		String e= request.getParameter("email");
		String epatt = 
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		if(s.getAttribute("ADMIN")!=null)
		{
			if(request.getParameter("code").equals("TRIPOD"))
			{
				Vendor v=new Vendor();
				v.setE_mail(request.getParameter("email"));
				v.setPassword(request.getParameter("pass"));
				AddVendor ob=new AddVendor();
				boolean value=ob.check(v);
				if(value==false)
					{
						if(e.matches(epatt)) {
						
						ob.add(v);
						RequestDispatcher rd=request.getRequestDispatcher("Admin_Home.jsp");
						request.setAttribute("error", "Vendor Added Successfully");
						rd.include(request, response);}
						else {
							RequestDispatcher rd=request.getRequestDispatcher("Admin_AddVendor.jsp");
							request.setAttribute("error", "please check the mail format ");
							rd.include(request, response);
						}
					}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("Admin_AddVendor.jsp");
					request.setAttribute("error", "This E-mail already exists. Try something new.");
					rd.include(request, response);
				}
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("Admin_AddVendor.jsp");
				request.setAttribute("error", "Check your Security Code");
				rd.include(request, response);
			}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Admin_Login.jsp");
			request.setAttribute("error", "Make sure you logged in");
			rd.include(request, response);
		}
	}

}

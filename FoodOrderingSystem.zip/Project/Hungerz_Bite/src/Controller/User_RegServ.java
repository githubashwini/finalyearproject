package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Action_Class.UserRegistration;
import Model.User1;

/**
 * Servlet implementation class User_RegServ
 */
@WebServlet(name = "User_Reg", urlPatterns = { "/User_Reg" })
public class User_RegServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public User_RegServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User1 user=new User1();
		user.setAddress(request.getParameter("add"));
		user.setContact(request.getParameter("contact"));
		user.setE_mail(request.getParameter("email"));
		user.setGender(request.getParameter("gender"));
		user.setName(request.getParameter("name"));
		user.setPassword(request.getParameter("pass"));
		String p=request.getParameter("pass");
		String cp=request.getParameter("confpass");
		String a=request.getParameter("add");
		String c=request.getParameter("contact");
		String e=request.getParameter("email");
		String g=request.getParameter("gender");
		String n=request.getParameter("name");
		String epat = 
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
				+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		/*if(p.equals(null) && cp.equals(null) && a.equals(null) && c.equals(null) && e.equals(null) && g.equals(null) && n.equals(null)  ) {
			RequestDispatcher rd=request.getRequestDispatcher("Userreg.jsp");
			request.setAttribute("error", "fields can not be null ");
			rd.include(request, response);	
		}
		else {*/
		/*if( (p.length()==0)&&(cp.length()==0)&&(a.length()==0)&& (c.length()==0)&&(e.length()==0)&&(g.length()==0)&&(n.length()==0)) {
			RequestDispatcher rd=request.getRequestDispatcher("Userreg.jsp");
			request.setAttribute("error", "fields can not be null");
			rd.include(request, response);
		}
		else {*/
		if(p.matches(cp)) 
		{
			if(e.matches(epat)) 
			{	if(c.matches("^[0-9]*$")) 
				{		
					UserRegistration ob=new UserRegistration();
					ob.register(user);
					RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
					request.setAttribute("error", "Account created Successfully");
					rd.include(request, response);
				}
			    else
			    {
			    	RequestDispatcher rd=request.getRequestDispatcher("Userreg.jsp");
					request.setAttribute("error", "Contact no. must be in numerics");
					rd.include(request, response);
			    }
			 }
			
			else 
			{
			RequestDispatcher rd=request.getRequestDispatcher("Userreg.jsp");
			request.setAttribute("error", "check your mail format");
			rd.include(request, response);
			}
	   }
		else{
			RequestDispatcher rd=request.getRequestDispatcher("Userreg.jsp");
			request.setAttribute("error", "password and confirm password don't match ");
			rd.include(request, response);
		}
		}/*}*//*}*/

}

package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Admin_LoginServ
 */
@WebServlet(name = "Admin_Login", urlPatterns = { "/Admin_Login" })
public class Admin_LoginServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Admin_LoginServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		String id=request.getParameter("id");
		String pass=request.getParameter("password");
		if(id.equals("TRIPOD")&&pass.equals("TRIPOD"))
		{
			s.setAttribute("ADMIN", id);
			response.sendRedirect("Admin_Home.jsp");
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Admin_Login.jsp");
			request.setAttribute("error", "Check your username and password");
			rd.include(request, response);
		}
	}

}

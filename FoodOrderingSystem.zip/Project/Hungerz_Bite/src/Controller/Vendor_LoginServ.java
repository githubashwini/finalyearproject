package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Action_Class.Vendor_Login;
import Model.Vendor;

/**
 * Servlet implementation class Vendor_LoginServ
 */
@WebServlet(name = "Vendor_Login", urlPatterns = { "/Vendor_Login" })
public class Vendor_LoginServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vendor_LoginServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		Vendor v=new Vendor();
		v.setE_mail(request.getParameter("id"));
		v.setPassword(request.getParameter("password"));
		Vendor_Login ob=new Vendor_Login();
		boolean value=ob.login(v);
		
		if(value)    //true matlab login
		{
			s.setAttribute("VENDOR", v.getE_mail());
			response.sendRedirect("Vendor_Home.jsp");
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Login.jsp");
			request.setAttribute("error", "Check your username and password");
			rd.include(request, response);
		}
	}

}

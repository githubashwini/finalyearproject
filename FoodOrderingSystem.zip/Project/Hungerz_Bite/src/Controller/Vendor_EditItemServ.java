package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Action_Class.Vendor_EditItem;
import Model.Items;

/**
 * Servlet implementation class Vendor_EditItemServ
 */
@WebServlet(name = "Vendor_EditItem", urlPatterns = { "/Vendor_EditItem" })
public class Vendor_EditItemServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vendor_EditItemServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		if(s.getAttribute("VENDOR")!=null)
		{
			Items i=new Items();
			i.setName(request.getParameter("name"));
			i.setPicture(request.getParameter("image"));
			i.setPrice(Double.parseDouble(request.getParameter("price")));
			i.setType(request.getParameter("type"));
			i.setIid(request.getParameter("iid"));
			
			Vendor_EditItem ob=new Vendor_EditItem();
			ob.edit(i);
			
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Menu.jsp");
			request.setAttribute("error", "Item Updated successfully");
			rd.include(request, response);
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Login.jsp");
			request.setAttribute("error", "Make sure you are logged in");
			rd.include(request, response);
		}
	}

}

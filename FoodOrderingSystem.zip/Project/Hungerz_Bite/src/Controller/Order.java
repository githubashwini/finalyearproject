package Controller;

import java.io.IOException;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Action_Class.Buy;
import Action_Class.Check_orderid;
import Action_Class.Generate_random_orderid;


/**
 * Servlet implementation class Order
 */
@WebServlet("/Order")
public class Order extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Order() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		String x=(String) s.getAttribute("USER");
		if(x!=null)
		{
			Double tot=Double.parseDouble(request.getParameter("total"));
			Generate_random_orderid oid= new Generate_random_orderid();
			String random_orderid=oid.getAlphaNumeric();
			Check_orderid chck=new Check_orderid();
			boolean isunique=chck.check(random_orderid);
			if(isunique)
			{
				int q[]=new int[100];
				Double p[]=new Double[100];
				String iid[]=new String[100];
				String iname[]=new String[100];
				String cid[]=new String[100];
				String address=null,uid=null,vid=null;
				int i=0;
				try
				{
					Class.forName("oracle.jdbc.driver.OracleDriver");
					Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","TRIPOD","TRIPOD");
					Statement st=con.createStatement();
					ResultSet rs=st.executeQuery("Select * from CART,USERDB,ITEMS where USERDB.E_MAIL='"+x+"' and USERDB.USERID=CART.USERID and CART.ITEMID=ITEMS.IID");
					while(rs.next())
					{
						cid[i]=rs.getString("CID");
						iid[i]=rs.getString("ITEMID");
						q[i]=Integer.parseInt(rs.getString("QUANTITY"));
						p[i]=Double.parseDouble(rs.getString("PRICE"));
						iname[i]=rs.getString(14);   //item name ka col number
						address=rs.getString("ADDRESS");
						uid=rs.getString("USERID");
						vid=rs.getString("VENDORID");
						++i;
					}
					
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
				for(int j=0;j<i;j++)	// j<i qk upar dekho i was incremented at the end
				{
					Model.Order o=new Model.Order();
					o.setAddress(address);
					o.setCartid(cid[j]);      //aise laga ke dekhe toh error aa rha tha so upr kia
					o.setItemid(iid[j]);
					o.setItemname(iname[j]);
					o.setOrderid(random_orderid);
					o.setPrice(p[j]);
					o.setQuantity(q[j]);
					o.setTotal(tot);
					o.setUserid(uid);
					o.setVendorid(vid);
					Buy buy=new Buy();
					buy.placeorder(o);
					buy.deletecart(cid[j]);
				}
				RequestDispatcher rd=request.getRequestDispatcher("Home.jsp");
				request.setAttribute("error", "Your Order has been placed");
				rd.include(request, response);
			}
			else
			{
				//matlab agar unique order id generate nahi hota hai then 
				Order order=new Order();
				order.doGet(request, response);
			}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Login.jsp");
			request.setAttribute("error", "Make sure you logged in");
			rd.include(request, response);
		}
	}

}

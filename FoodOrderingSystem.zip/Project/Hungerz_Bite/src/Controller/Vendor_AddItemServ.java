package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Action_Class.Vendor_AddItem;
import Model.Items;

/**
 * Servlet implementation class Vendor_AddItemServ
 */
@WebServlet(name = "Vendor_AddItem", urlPatterns = { "/Vendor_AddItem" })
public class Vendor_AddItemServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Vendor_AddItemServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		String n=request.getParameter("name");
		String p=request.getParameter("price");
		String t= request.getParameter("type");
		if(s.getAttribute("VENDOR")!=null)
		{
			Items item=new Items();
			item.setName(request.getParameter("name"));
			item.setPicture(request.getParameter("picture"));
			item.setPrice(Double.parseDouble(request.getParameter("price")));
			item.setType(request.getParameter("type"));
			String str=(String)s.getAttribute("VENDOR");
			if(p.matches("^[0-9]*$")) {
			Vendor_AddItem ob=new Vendor_AddItem();
			ob.add(item,request.getParameter("category"),str);
			
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Menu.jsp");
			request.setAttribute("error", "Item added successfully");
			rd.include(request, response);}
			else {
				RequestDispatcher rd=request.getRequestDispatcher("Vendor_Login.jsp");
				request.setAttribute("error", "price should be in numerics");
				rd.include(request, response);
			}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("Vendor_Login.jsp");
			request.setAttribute("error", "Make sure you are logged in");
			rd.include(request, response);
		}
	}

}

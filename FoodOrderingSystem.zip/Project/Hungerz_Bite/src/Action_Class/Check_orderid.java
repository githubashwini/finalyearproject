package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Order;

public class Check_orderid {
	public boolean check(String str)
	{
		Session s= new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
				
			String hql="from "+Order.class.getName()+" where ORDERID=:oid";
			Query query=s.createQuery(hql);
			query.setParameter("oid",str);
			
			Object value=query.uniqueResult();
			if(value==null)    //matlab is name ka order id nahi hai. it means generated wala unique hai 
				return true;   //matlab Han unique hai
			else
				return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		return false;
	}

}

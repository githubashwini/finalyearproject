package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.User1;

public class Userlogin {

	public boolean login(String email, String pass) {
		Session s= new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
				
			String hql="from "+User1.class.getName()+" where e_mail=:email and password=:pass";
			Query query=s.createQuery(hql);
			query.setParameter("email",email);
			query.setParameter("pass",pass);
			
			Object value=query.uniqueResult();
			if(value!=null)    //matlab is name ka Email hai   
				return true;   
			else
				return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		return false;
		
		
	}

}

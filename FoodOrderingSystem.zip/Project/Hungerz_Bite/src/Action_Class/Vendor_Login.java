package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Vendor;

public class Vendor_Login {

	public boolean login(Vendor v) {
		Session s= new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			String e_mail=v.getE_mail();
			String pass=v.getPassword();
			String hql="from "+Vendor.class.getName() +" where e_mail=:e_mail and password=:pass";
			Query query=s.createQuery(hql);
			query.setParameter("e_mail", e_mail);
			query.setParameter("pass", pass);
			//int i=query.executeUpdate();
			//List list=query.list();
			Object value=query.uniqueResult();
			if(value!=null)       //kuch hai
				return true;
			else
				return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		return false;
		
	}

}

package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Vendor;

public class AddVendor {

	public boolean check(Vendor v) {
		Session s= new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			String e_mail=v.e_mail;
			String hql="from "+Vendor.class.getName() +" where e_mail=:e_mail";
			Query query=s.createQuery(hql);
			query.setParameter("e_mail", e_mail);
			//int i=query.executeUpdate();
			//List list=query.list();
			Object value=query.uniqueResult();
			if(value!=null)    //matlab is name ka Email hai   
				return true;   
			else
				return false;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		return true;
		
	}

	public void add(Vendor v) {
		Session s=new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			Transaction t=s.beginTransaction();
			s.save(v);
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}

}

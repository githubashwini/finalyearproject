package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Category;
import Model.Items;
import Model.Vendor;

public class Vendor_AddItem {

	public void add(Items item, String cat, String str) {
		Session s=new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			//setting vendor object in item class
			String hql="from "+Vendor.class.getName()+" where E_MAIL=:str";
			Query query=s.createQuery(hql);
			query.setParameter("str",str);
			Object v=query.uniqueResult();
			item.setVendor((Vendor)v);
			//setting category object in item class
			String hql1="from "+Category.class.getName()+" where NAME=:cat";
			Query query1=s.createQuery(hql1);
			query1.setParameter("cat",cat);
			Object c=query1.uniqueResult();
			item.setCategory((Category)c);;
			
			
			Transaction t=s.beginTransaction();
			s.save(item);
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}

}

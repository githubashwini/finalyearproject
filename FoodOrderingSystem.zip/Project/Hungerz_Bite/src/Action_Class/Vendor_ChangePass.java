package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Vendor;

public class Vendor_ChangePass {

	public void change(String str, String password) {
		Session s=new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		try
		{
			
			Transaction t=s.beginTransaction();
			String hql="update "+Vendor.class.getName()+" set PASSWORD=:password where E_MAIL=:str";
			Query query=s.createQuery(hql);
			query.setParameter("password", password);
			query.setParameter("str",str);
			query.executeUpdate();
			//s.save(user);
			t.commit();
			System.out.println("Password has been Updated");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}

}

package Action_Class;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Cart;

public class Addtocart {
	public void add(Cart c)
	{
		Session s=new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			Transaction t=s.beginTransaction();
			s.save(c);
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
	}
}

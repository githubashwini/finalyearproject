package Action_Class;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.User1;

public class UserRegistration {

	public void register(User1 user) {
		Session s=new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			Transaction t=s.beginTransaction();
			s.save(user);
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}

}

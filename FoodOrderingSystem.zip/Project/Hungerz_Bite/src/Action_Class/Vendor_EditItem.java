package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Items;

public class Vendor_EditItem {

	public void edit(Items i) {
		Session s=new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		try
		{
			String name=i.getName();
			Double price=i.getPrice();
			String type=i.getType();
			String picture=i.getPicture();
			String x=i.getIid();
			
			Transaction t=s.beginTransaction();
			String hql="update "+Items.class.getName()+" set NAME=:name, PRICE=:price, TYPE=:type, PICTURE=:picture where IID=:x";
			Query query=s.createQuery(hql);
			query.setParameter("name", name);
			query.setParameter("price", price);
			query.setParameter("type",type);
			query.setParameter("picture",picture );
			query.setParameter("x",x );
			int io=query.executeUpdate();
			//s.save(user);
			t.commit();
			System.out.println(+io+" Row(s) affected");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}


}

package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Category;
import Model.Vendor;

public class Vendor_AddCategory {

	public void add(String str, String cat) {
		Session s= new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			Category c=new Category();
			
			String hql="from "+Vendor.class.getName()+" where E_MAIL=:str";
			Query query=s.createQuery(hql);
			query.setParameter("str",str);
			//query.executeUpdate();
			Object v=query.uniqueResult();
			//List results=(List) query.list();
			//Vendor v=(Vendor)((Object)results);
			
			c.setName(cat);
			c.setVendor((Vendor)v);
			Transaction t=s.beginTransaction();
			s.save(c);
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}

}

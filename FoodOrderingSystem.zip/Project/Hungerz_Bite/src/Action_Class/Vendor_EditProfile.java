package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Vendor;

public class Vendor_EditProfile {

	public void edit(Vendor v) {
		Session s=new AnnotationConfiguration().configure("hibernate.cfg.xml").buildSessionFactory().openSession();
		try
		{
			String city=v.getCity();
			String contact=v.getContact();
			String name=v.getName();
			String locality=v.getLocality();
			String picture=v.getPicture();
			String email=v.getE_mail();
			
			Transaction t=s.beginTransaction();
			String hql="update "+Vendor.class.getName()+" set CITY=:city, CONTACT=:contact, LOCALITY=:locality, NAME=:name, PICTURE=:picture where E_MAIL=:x";
			Query query=s.createQuery(hql);
			query.setParameter("city", city);
			query.setParameter("contact", contact);
			query.setParameter("name",name);
			query.setParameter("locality",locality );
			query.setParameter("picture", picture);
			query.setParameter("x",email );
			int i=query.executeUpdate();
			//s.save(user);
			t.commit();
			System.out.println(+i+" Row(s) affected");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}

}

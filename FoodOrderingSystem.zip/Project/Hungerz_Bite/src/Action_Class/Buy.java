package Action_Class;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

import Model.Cart;
import Model.Order;

public class Buy {

	public void placeorder(Order o) {
		Session s=new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			Transaction t=s.beginTransaction();
			s.save(o);
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
		
	}
	public void deletecart(String cid) {
		Session s=new AnnotationConfiguration().configure().buildSessionFactory().openSession();
		try
		{
			Transaction t=s.beginTransaction();
			String hql="delete from "+Cart.class.getName()+" where  CID=:cid";
			Query query=s.createQuery(hql);
			query.setParameter("cid", cid);
			query.executeUpdate();
			t.commit();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			s.flush();
			s.close();
		}
	}

}

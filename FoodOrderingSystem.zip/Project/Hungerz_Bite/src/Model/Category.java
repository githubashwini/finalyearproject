package Model;

import javax.persistence.*;

@Entity
@Table
public class Category {
	public String catid;
	public String name;
	
	public Vendor vendor;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public String getCatid() {
		return catid;
	}

	public void setCatid(String catid) {
		this.catid = catid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@OneToOne
	@JoinColumn(name="vendor_id")
	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}
	
	
}

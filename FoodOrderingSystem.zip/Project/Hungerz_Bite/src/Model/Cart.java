package Model;

import javax.persistence.*;

@Entity
@Table
public class Cart {
	public String cid;
	public int quantity;
	public String itemid;
	public String userid;
	public String vendorid;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getItemid() {
		return itemid;
	}
	public void setItemid(String itemid) {
		this.itemid = itemid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getVendorid() {
		return vendorid;
	}
	public void setVendorid(String vendorid) {
		this.vendorid = vendorid;
	}
	
	
}

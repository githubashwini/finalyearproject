package Model;

import javax.persistence.*;

@Entity
@Table
public class Admin {
	public String aid;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public String getAid() {
		return aid;
	}

	public void setAid(String aid) {
		this.aid = aid;
	}
	
}
